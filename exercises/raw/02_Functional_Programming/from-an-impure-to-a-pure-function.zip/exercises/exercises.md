Exercises 1 - 4

- Convert the given impure functions to pure ones.
- The idea of this "conversion" is to preserve the expressed meaning of the code while changing the technical solution

HINTS:
- Analyse the function of interest, focus on the cause of impurity and remove it from the function.
- The provided unit-tests will give you no clue whether a function is pure or not.