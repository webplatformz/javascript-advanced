describe("is getDocument() pure or impure ?", () => {

  it("is pure | impure", () => {

    function getDocument() {
      return global.window.document;
    }
    getDocument()

    let result = getDocument();

    console.log("--- exercise 11");
    console.log(result);

  });

});


